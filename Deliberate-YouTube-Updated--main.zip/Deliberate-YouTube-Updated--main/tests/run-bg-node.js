// Node-based runner for the background-service-worker test suite.
// Usage (no Node installed): set ELECTRON_RUN_AS_NODE=1 then run
//   Devin.exe tests/run-bg-node.js
// Reuses tests/harness.js for the chrome.* mock, then loads background.js and
// executes the same assertions as bg-test.html.

global.window = {};
global.document = {
  getElementById: function () { return null; },
  createElement: function () { return { appendChild: function () {} }; },
  body: { appendChild: function () {} }
};

require('./harness.js');
global.chrome = global.window.chrome;
require('../background.js');

var T = global.window.__test;

(async function () {
  await new Promise(function (r) { setTimeout(r, 50); });

  // 1. onInstalled merges defaults into existing settings
  T.store['settings'] = { hasCompletedOnboarding: true, hideShorts: true, usualPurpose: 'Learn something', reflectionInterval: 30 };
  await T.fireInstalled();
  var s = T.store['settings'];
  T.assert('install preserves existing settings', s.hasCompletedOnboarding === true && s.hideShorts === true && s.reflectionInterval === 30);
  T.assert('install adds simplifiedMode default OFF', s.simplifiedMode === false);
  T.assert('install adds reflectionPopup default ON', s.reflectionPopup === true);
  T.assert('install preserves sessions array', Array.isArray(T.store['sessions']));

  // 2. Session-stopwatch model: feedback uses currentSession.startTime
  var r1 = await T.sendToBg({ action: 'ytTabHeartbeat' });
  T.assert('heartbeat returns show:false below threshold', r1 && r1.show === false);
  T.assert('no-session fallback stamped ytSessionStart', !!(T.store['feedbackPrompt'] || {}).ytSessionStart);
  T.store['feedbackPrompt'] = { ytSessionStart: Date.now() - 901000, shown: false, granted: false };
  await T.sendToBg({ action: 'ytTabHeartbeat' });
  T.assert('no-session stopwatch at 15min grants', T.store['feedbackPrompt'].granted === true);
  T.store['feedbackPrompt'] = { shown: false, granted: false };
  T.store['currentSession'] = { id: 's1', startTime: Date.now() - 901000, intention: 'x' };
  var r2 = await T.sendToBg({ action: 'ytTabHeartbeat' });
  T.assert('session stopwatch at 900s grants', T.store['feedbackPrompt'].granted === true);
  T.assert('pending grant reports show:true', r2 && r2.show === true);
  var r3 = await T.sendToBg({ action: 'ytTabHeartbeat' });
  T.assert('still showable until displayed (pending)', r3 && r3.show === true);
  T.store['feedbackPrompt'] = { shown: false, granted: false };
  T.store['currentSession'] = { id: 's2', startTime: Date.now() - 10000, intention: 'x' };
  var rUnder = await T.sendToBg({ action: 'ytTabHeartbeat' });
  T.assert('10s session does not grant', T.store['feedbackPrompt'].granted !== true && rUnder.show === false);
  T.store['currentSession'] = { id: 's3', startTime: Date.now() - 950000, intention: 'x' };
  await T.fireAlarm('iyFeedbackTick');
  await new Promise(function (r) { setTimeout(r, 100); });
  T.assert('alarm re-eval grants at 950s elapsed', T.store['feedbackPrompt'].granted === true);
  T.store['currentSession'] = null;

  // 3. markFeedbackShown persists shown state
  await T.sendToBg({ action: 'markFeedbackShown' });
  var r4 = await T.sendToBg({ action: 'ytTabHeartbeat' });
  T.assert('after shown, never shows again', r4 && r4.show === false);
  T.assert('shown persisted in storage', T.store['feedbackPrompt'].shown === true);

  // 4. openExternalUrl whitelist
  var good = await T.sendToBg({ action: 'openExternalUrl', url: 'https://forms.gle/9EvNL9p62dW3TFmo6' });
  var bad = await T.sendToBg({ action: 'openExternalUrl', url: 'https://evil.example.com/' });
  T.assert('feedback URL opens', good && good.success === true && T.createdTabs.indexOf('https://forms.gle/9EvNL9p62dW3TFmo6') !== -1);
  T.assert('non-whitelist URL rejected', bad && bad.success === false && T.createdTabs.indexOf('https://evil.example.com/') === -1);
  var store = await T.sendToBg({ action: 'openExternalUrl', url: 'https://chromewebstore.google.com/detail/deliberate-youtube/gkhfmpgkclckdkbhlkbcelhnigdclklp' });
  T.assert('webstore URL opens', store && store.success === true);

  // 5. updateBehaviorTracking credits foreground elapsed to previous bucket
  var sres = await T.sendToBg({ action: 'startSession', data: { intention: 'Learn something', goal: '' } });
  T.assert('startSession succeeds', sres && sres.success === true);
  await T.sendToBg({ action: 'updateBehaviorTracking', data: { activity: 'homepage', elapsedMs: 0 } });
  await T.sendToBg({ action: 'updateBehaviorTracking', data: { activity: 'video', elapsedMs: 60000 } });
  var sess = T.store['currentSession'];
  T.assert('elapsed credited to previous bucket (homepage)', sess.timeOnHomepage === 60000 && sess.timeOnVideo === 0);
  T.assert('activity switch counted', sess.activitySwitches >= 2);
  await T.sendToBg({ action: 'updateBehaviorTracking', data: { activity: 'video', elapsedMs: 5000 } });
  sess = T.store['currentSession'];
  T.assert('same-activity report credits video bucket', sess.timeOnVideo === 5000);

  var lines = T.results.map(function (r) { return (r.pass ? 'PASS ' : 'FAIL ') + r.name + (r.detail ? ' :: ' + r.detail : ''); });
  console.log(lines.join('\n'));
  var passed = T.results.filter(function (r) { return r.pass; }).length;
  console.log('=== ' + passed + '/' + T.results.length + ' passed ===');
  process.exit(passed === T.results.length ? 0 : 1);
})().catch(function (e) { console.log('RUNNER ERROR: ' + (e && e.stack || e)); process.exit(1); });
