// Shared test harness: minimal chrome.* mock + result reporting.
// Loaded before the extension scripts under test.
(function () {
  var store = {};
  var storageListeners = [];
  var onMessageListeners = [];
  var onInstalledListeners = [];
  var onUpdatedListeners = [];
  var onRemovedListeners = [];
  var alarmListeners = [];
  var createdTabs = [];

  function storageGet(keys) {
    var out = {};
    if (keys == null) return Promise.resolve(Object.assign({}, store));
    var list = Array.isArray(keys) ? keys : [keys];
    list.forEach(function (k) { if (k in store) out[k] = store[k]; });
    return Promise.resolve(out);
  }
  function storageSet(obj) {
    var changes = {};
    Object.keys(obj).forEach(function (k) {
      changes[k] = { oldValue: store[k], newValue: obj[k] };
      store[k] = obj[k];
    });
    storageListeners.forEach(function (l) { try { l(changes, 'local'); } catch (e) {} });
    return Promise.resolve();
  }
  function storageRemove(keys) {
    var list = Array.isArray(keys) ? keys : [keys];
    var changes = {};
    list.forEach(function (k) { changes[k] = { oldValue: store[k], newValue: undefined }; delete store[k]; });
    storageListeners.forEach(function (l) { try { l(changes, 'local'); } catch (e) {} });
    return Promise.resolve();
  }

  window.chrome = {
    runtime: {
      id: 'test-extension-id',
      onMessage: { addListener: function (l) { onMessageListeners.push(l); } },
      onInstalled: { addListener: function (l) { onInstalledListeners.push(l); } },
      sendMessage: function (msg) {
        // Dispatch to the last registered listener (background.js registers
        // its own; in combined tests we pick by handler response).
        var results = [];
        var pending = onMessageListeners.map(function (l) {
          return new Promise(function (resolve) {
            var handled = l(msg, {}, function (r) { resolve(r); });
            if (!handled) resolve(undefined);
          });
        });
        return Promise.all(pending).then(function (rs) {
          var defined = rs.filter(function (r) { return r !== undefined; });
          return defined.length ? defined[defined.length - 1] : undefined;
        });
      },
      getURL: function (p) { return 'chrome-extension://test/' + p; }
    },
    storage: {
      local: { get: storageGet, set: storageSet, remove: storageRemove },
      onChanged: { addListener: function (l) { storageListeners.push(l); } }
    },
    tabs: {
      create: function (opts) { createdTabs.push(opts.url); return Promise.resolve({ id: createdTabs.length }); },
      query: function () { return Promise.resolve([]); },
      sendMessage: function () { return Promise.resolve(); },
      remove: function () { return Promise.resolve(); },
      onUpdated: { addListener: function (l) { onUpdatedListeners.push(l); } },
      onRemoved: { addListener: function (l) { onRemovedListeners.push(l); } }
    },
    alarms: {
      create: function () {},
      onAlarm: { addListener: function (l) { alarmListeners.push(l); } }
    }
  };

  window.__test = {
    store: store,
    createdTabs: createdTabs,
    fireInstalled: function () { return Promise.all(onInstalledListeners.map(function (l) { return l(); })); },
    sendToBg: function (msg) { return window.chrome.runtime.sendMessage(msg); },
    fireAlarm: function (name) { return Promise.all(alarmListeners.map(function (l) { return Promise.resolve(l({ name: name })); })); },
    fireStorageChange: function (changes) {
      storageListeners.forEach(function (l) { l(changes, 'local'); });
    },
    results: [],
    assert: function (name, cond, detail) {
      window.__test.results.push({ name: name, pass: !!cond, detail: detail || '' });
    },
    report: function () {
      var el = document.getElementById('results');
      if (!el) { el = document.createElement('pre'); el.id = 'results'; document.body.appendChild(el); }
      el.textContent = window.__test.results.map(function (r) {
        return (r.pass ? 'PASS ' : 'FAIL ') + r.name + (r.detail ? ' :: ' + r.detail : '');
      }).join('\n') + '\n=== ' + window.__test.results.filter(function (r) { return r.pass; }).length + '/' + window.__test.results.length + ' passed ===';
    }
  };
})();
